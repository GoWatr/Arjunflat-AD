// board version 3.2.0
#include "Functions.h"
#include "esp_system.h"
#include "rom/ets_sys.h"

const int wdtTimeout = 20000;  // Time in ms to trigger the watchdog
hw_timer_t *timer = NULL;

// void ARDUINO_ISR_ATTR resetModule() {
//   ets_printf("reboot\n");
//   esp_restart();
// }
void setup() {
  pinMode(22, OUTPUT);
  Serial.begin(115200);
  pinMode(SUMP_MOTOR1, OUTPUT);
  pinMode(SUMP_MOTOR2, OUTPUT);
  pinMode(OHT_MOTOR1, OUTPUT);
  pinMode(OHT_MOTOR2, OUTPUT);

  pinMode(analogPin, INPUT);   // ADC for Sump
  pinMode(analogPin2, INPUT);  // ADC for OHT 

  digitalWrite(SUMP_MOTOR1, LOW);
  digitalWrite(SUMP_MOTOR2, LOW);
  digitalWrite(OHT_MOTOR1, LOW);
  digitalWrite(OHT_MOTOR2, LOW);
  WiFi.begin(ssid, password);
  delay(4000);
  if (WiFi.status() == WL_CONNECTED) {
    Serial.println("WiFi is connected");
    digitalWrite(22, HIGH);
  } else if (WiFi.status() != WL_CONNECTED) {
    Serial.println("WiFi is NOT connected");
    digitalWrite(22, LOW);
    WiFi.reconnect();
  }
  // timer = timerBegin(0, 80, true);                 // Timer 0, 1 MHz resolution (80 MHz / 80)
  // timerAttachInterrupt(timer, &resetModule, true); // Attach callback, edge triggered
  // timerAlarmWrite(timer, wdtTimeout * 1000, false); // Set time in us
  // timerAlarmEnable(timer);
}

void loop() {
  timerWrite(timer, 0);  // Reset timer (feed watchdog)
  currentTime = millis();
  sensor_read();
  counter_timer();
  checkMotorStatusSUMP();
  checkMotorStatusOHT();

  datatosend = (url + ID1 + String(SM1S) + ID2 + String(SM2S) + ID3 + String(sump_adc) + ID4 + String(sump_level_percentage)
                + ID5 + String(oht_adc) + ID6 + String(oht_level_percentage) + ID7 + String(OM1S) + ID8 + String(OM2S) + ID9 + String(C_Date) + ID10 + String(C_Time) + ID11 + String(CurrentVersion));

  if (currentTime - lastmotorcontrol60 >= motorcontrol60) {
    lastmotorcontrol60 = currentTime;
    if ((sump_adc != -1) && (sump_level_percentage <= 60) && (daily_motor_swap_sump == 0)) {
      controlMotor(1, true);
      delay(100);
    } else if ((sump_level_percentage > 85) || (sump_adc == -1)) {
      controlMotor(1, false);
      delay(100);
    }
    if ((sump_adc != -1) && (sump_level_percentage <= 60) && (daily_motor_swap_sump == 1)) {
      controlMotor(2, true);
      delay(100);
    } else if ((sump_level_percentage > 85) || (sump_adc == -1)) {
      controlMotor(2, false);
      delay(100);
    }

    if ((oht_adc != -1) && (oht_level_percentage <= 55) && (sump_level_percentage >= 40) && (daily_motor_swap_oht == 0)) {
      controlMotor(3, true);
      delay(100);
    } else if ((oht_level_percentage > 90) || (oht_adc == -1)) {
      controlMotor(3, false);
      delay(100);
    }
    if ((oht_adc != -1) && (oht_level_percentage <= 55) && (sump_level_percentage >= 40) && (daily_motor_swap_oht == 1)) {
      controlMotor(4, true);
      delay(100);
    } else if ((oht_level_percentage > 90) || (oht_adc == -1)) {
      controlMotor(4, false);
      delay(100);
    }
  }
  if (currentTime - lastDataSendTime >= data_send_counter) {
    lastDataSendTime = currentTime;
    wifi_connection();
    delay(200);
    Send_Data_WIFI(datatosend);
  }

  /////////////////////serialprint/////////////////////////
  if (currentTime - lastserialprintTime >= serialprint) {
    lastserialprintTime = currentTime;
    Serial.println("");
    date_time();
    Serial.println("Sump tank waterlevel is " + String(sump_level_percentage) + "%" + "\tSump ADC Value: " + String(sump_adc));
    Serial.println("OHT tank waterlevel is " + String(oht_level_percentage) + "%" + "\tOHT ADC Value: " + String(oht_adc));
    Serial.println("OHT_MOTOR1 : " + String(OM1S) + "\tOHT_MOTOR2 : " + String(OM2S) + "\tOHT Motor status is  " + String(daily_motor_swap_oht));
    Serial.println("SUMP_MOTOR1: " + String(SM1S) + "\tSUMP_MOTOR2: " + String(SM2S) + "\tSUMP Motor status is " + String(daily_motor_swap_sump));
    Serial.println(datatosend);
    Serial.print("");
  }

  if (currentTime - lastUpdateCheck >= checkverupdate) {
    lastUpdateCheck = currentTime;
    check_for_updates();
  }

  if (currentTime > 3888000000)  //32 bit 4294967295 = 49.71 days / 32 bit 3888000000 = 45days
  {
    Serial.println("Restarting ESP32...");
    ESP.restart();
  }
}
