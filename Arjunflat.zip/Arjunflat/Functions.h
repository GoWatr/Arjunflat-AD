
#define CurrentVersion 16
#define LED_BUILTIN 2
#define SUMP_MOTOR1 32
#define SUMP_MOTOR2 33
#define OHT_MOTOR1 25
#define OHT_MOTOR2 26

#include <SoftwareSerial.h>
#include <WiFi.h>
#include <HTTPClient.h>
#include <WiFiClient.h>
#include <HTTPUpdate.h>
#include <ArduinoJson.h>
#include "math.h"
#include "ota.h"
WiFiClient wifiClient;

//#include <Adafruit_ADS1015.h> // version 1.0.0
//Adafruit_ADS1115 ads(0x48);

String ID1 = "smo:";
String ID2 = ",smt:";
String ID3 = ",sraw:";
String ID4 = ",sper:";
String ID5 = ",ohtraw:";
String ID6 = ",ohtper:";
String ID7 = ",ohtmo:";
String ID8 = ",ohtmt:";
String ID9 = ",iotd:";
String ID10 = ",iott:";
String ID11 = ",Ver:";
String C_Date;
String C_Time;
const size_t capacity = JSON_OBJECT_SIZE(3) + 60;
const char* time_url = "http://www.gowatr.com/wms/getdata/time.php?datetime=time";
const char* date_url = "http://www.gowatr.com/wms/getdata/time.php?datetime=date";
String url = "http://www.gowatr.com/wms/pushdata/arjunflats.php?id=arjunflats&data=";
String datatosend = "";

float sump_sensor_voltage = 0.0;
float oht_sensor_voltage = 0.0;
float sump_maximum_level = 1700;  //9970; 1700 / 2000
float oht_maximum_level = 1600;   // 7000
float sump_level_percentage;
float oht_level_percentage;

int SM1S = 0;
int SM2S = 0;
int OM1S = 0;
int OM2S = 0;
int daily_motor_swap_sump = 0;
int daily_motor_swap_oht = 0;

int writeInterval = 1000;
int16_t oht_adc;
int16_t oht_adc_current;
int16_t sump_adc;
int16_t sump_adc_current;
float previous_value_sump_S1, previous_value_sump_S2 = 0.0;
float compare_value_sump_S1, compare_value_sump_S2 = 0.0;
float previous_value_oht_O1, previous_value_oht_O2 = 0.0;
float compare_value_oht_O1, compare_value_oht_O2 = 0.0;

const char* ssid = "Airtel_kanc_2048";
const char* password = "air68933";
const char* DATE;
const char* TIME;

unsigned long lastTime, lastDataSendTime, lastserialprintTime, lastmotorcontrol60 = 0;
int counter_S1, counter_S2, counter_O1, counter_O2, sensor_counter = 0;
const unsigned long perless = 7 * 60 * 1000;
const unsigned long motor_switching_time = 24 * 60 * 60 * 1000;
const unsigned long motorcontrol60 = 20 * 1000;
int flag_S1, flag_S2, flag_O1, flag_O2 = 0;
const unsigned long data_send_counter = 90 * 1000;
unsigned long currentTime;
const unsigned long checkverupdate = 5 * 60 * 1000;
static unsigned long lastUpdateCheck, ifmotornw_S1, ifmotornw_S2, ifmotornw_O1, ifmotornw_O2 = 0;
int serialprint = 5000;
uint64_t temp, temp1, temp2;
float valueFloat1;
float valueFloat2;
float userFloat;


void wifi_connection() {
  if (WiFi.status() == WL_CONNECTED) {
    Serial.println("****************WiFi connected****************");
    digitalWrite(LED_BUILTIN, HIGH);
  } else if (WiFi.status() != WL_CONNECTED) {
    Serial.println("WiFi is NOT connected");
    WiFi.begin(ssid, password);
    delay(1000);
    digitalWrite(LED_BUILTIN, LOW);
  }
}

// REMOVE I2C ADS SENSOR
// #include <Adafruit_ADS1015.h>
// Adafruit_ADS1115 ads(0x48);

// ADD SECOND ANALOG PIN
#define analogPin 36        // sump sensor
#define analogPin2 39       // oht sensor  (NEW ANALOG SENSOR)

// ================== SENSOR READ FUNCTION ==================

void sensor_read() {

  // ========== SUMP ANALOG SENSOR (PIN 34) ==========
  const int numReadings = 20;
  for (int i = 0; i < numReadings; i++) {
    int current_sump_adc = analogRead(analogPin);
    temp = current_sump_adc;
    temp1 = (temp * temp);
    temp2 += temp1;
  }
  temp2 = sqrt(temp2 / 20);
  sump_adc = temp2;
  sump_sensor_voltage = (sump_adc * 3.3) / 4095;
  sump_level_percentage = ((sump_adc / sump_maximum_level) * 100);
  temp2 = 0;
  temp1 = 0;
  delay(500);

  // ========== OHT ANALOG SENSOR (PIN 35) – NEW SENSOR ==========
  const int numReadings2 = 20;
  uint64_t tempO = 0, temp1O = 0, temp2O = 0;

  for (int i = 0; i < numReadings2; i++) {
    int current_oht_adc = analogRead(analogPin2);
    tempO = current_oht_adc;
    temp1O = (tempO * tempO);
    temp2O += temp1O;
  }

  temp2O = sqrt(temp2O / 20);
  oht_adc = temp2O;

  oht_sensor_voltage = (oht_adc * 3.3) / 4095;
  oht_level_percentage = ((oht_adc / oht_maximum_level) * 100);

  delay(500);
}


void controlMotor(int motor, bool state) {
  switch (motor) {
    case 1:
      digitalWrite(SUMP_MOTOR1, state ? HIGH : LOW);
      SM1S = state ? 1 : 0;
      if (state) digitalWrite(SUMP_MOTOR2, LOW);
      break;
    case 2:
      digitalWrite(SUMP_MOTOR2, state ? HIGH : LOW);
      SM2S = state ? 1 : 0;
      if (state) digitalWrite(SUMP_MOTOR1, LOW);
      break;
    case 3:
      digitalWrite(OHT_MOTOR1, state ? HIGH : LOW);
      OM1S = state ? 1 : 0;
      if (state) digitalWrite(OHT_MOTOR2, LOW);
      break;
    case 4:
      digitalWrite(OHT_MOTOR2, state ? HIGH : LOW);
      OM2S = state ? 1 : 0;
      if (state) digitalWrite(OHT_MOTOR1, LOW);
      break;
    default:
      break;
  }
}

void counter_timer() {
  if (currentTime - lastTime >= motor_switching_time) {
    lastTime = currentTime;
    if (daily_motor_swap_sump == 0) {
      daily_motor_swap_sump = 1;
      controlMotor(1, false);
      delay(500);
    } else if (daily_motor_swap_sump == 1) {
      daily_motor_swap_sump = 0;
      controlMotor(2, false);
      delay(500);
    }
    if (daily_motor_swap_oht == 0) {
      daily_motor_swap_oht = 1;
      controlMotor(3, false);
      delay(500);
    } else if (daily_motor_swap_oht == 1) {
      daily_motor_swap_oht = 0;
      controlMotor(4, false);
      delay(500);
    }
  }
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////
void checkMotorStatusSUMP() {
  if (SM1S == 1) {
    if (flag_S1 == 0) {
      previous_value_sump_S1 = sump_level_percentage;
      Serial.println("previous" + String(previous_value_sump_S1) + "************************************************");
      flag_S1 = 1;
      ifmotornw_S1 = currentTime;
    }

    Serial.println("currentTime.........." + String(currentTime));
    Serial.println("ifmotornw_S1.........." + String(ifmotornw_S1));
    if (currentTime - ifmotornw_S1 >= perless) {
      ifmotornw_S1 = currentTime;

      previous_value_sump_S1 += 2.2;  // Increase by 3%
      compare_value_sump_S1 = previous_value_sump_S1;
      previous_value_sump_S1 = 0;
      Serial.println("sump_level_percentage, running motor 1:  " + String(sump_level_percentage) + "************************************************");
      Serial.println("compare_value_sump motor 1:  " + String(compare_value_sump_S1) + "************************************************");
      if (sump_level_percentage < compare_value_sump_S1) {
        Serial.println("SUMP MOTOR 1 NOT WORKING & MOTOR 2 STARTED************************************************");
        controlMotor(1, false);
        delay(500);
        controlMotor(2, true);
        delay(500);
        daily_motor_swap_sump = 1;
        flag_S1 = 0;
      } else {
        flag_S1 = 0;
      }
    }
  } else if (SM1S == 0) {
    flag_S1 = 0;
  }

  if (SM2S == 1) {
    if (flag_S2 == 0) {
      previous_value_sump_S2 = sump_level_percentage;
      Serial.println("previous" + String(previous_value_sump_S2) + "************************************************");
      flag_S2 = 1;
      ifmotornw_S2 = currentTime;
    }

    Serial.println("currentTime.........." + String(currentTime));
    Serial.println("ifmotornw_S2.........." + String(ifmotornw_S2));
    if (currentTime - ifmotornw_S2 >= perless) {
      ifmotornw_S2 = currentTime;

      previous_value_sump_S2 += 2.5;
      compare_value_sump_S2 = previous_value_sump_S2;
      previous_value_sump_S2 = 0;
      Serial.println("sump_level_percentage, running motor 2:  " + String(sump_level_percentage) + "************************************************");
      Serial.println("compare_value_sump motor 2:  " + String(compare_value_sump_S2) + "************************************************");
      if (sump_level_percentage < compare_value_sump_S2) {

        Serial.println("SUMP MOTOR 2 NOT WORKING & MOTOR 1 STARTED************************************************");
        controlMotor(2, false);
        delay(500);
        controlMotor(1, true);
        delay(500);
        daily_motor_swap_sump = 0;
        flag_S2 = 0;
      } else {
        flag_S2 = 0;
      }
    }
  } else if (SM2S == 0) {
    flag_S2 = 0;
  }
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void checkMotorStatusOHT() {
  if (OM1S == 1) {
    if (flag_O1 == 0) {
      previous_value_oht_O1 = oht_level_percentage;
      flag_O1 = 1;
      ifmotornw_O1 = currentTime;
    }
    if (currentTime - ifmotornw_O1 >= perless) {
      ifmotornw_O1 = currentTime;

      previous_value_oht_O1 += 2;  // Increase by 2%
      compare_value_oht_O1 = previous_value_oht_O1;
      previous_value_oht_O1 = 0;
      Serial.println("compare_value_oht:  " + String(compare_value_oht_O1) + "************************************************");
      if (oht_level_percentage < compare_value_oht_O1) {
        Serial.println("OHT MOTOR 1 NOT WORKING & MOTOR 2 STARTED************************************************");
        controlMotor(3, false);
        delay(500);
        controlMotor(4, true);
        delay(500);
        daily_motor_swap_oht = 1;
        flag_O1 = 0;
      } else {
        flag_O1 = 0;
      }
    }
  } else if (OM1S == 0) {
    flag_O1 = 0;
  }

  if (OM2S == 1) {

    if (flag_O2 == 0) {
      previous_value_oht_O2 = oht_level_percentage;
      flag_O2 = 1;
      ifmotornw_O2 = currentTime;
    }

    if (currentTime - ifmotornw_O2 >= perless) {
      ifmotornw_O2 = currentTime;

      previous_value_oht_O2 += 2;  // Increase by 2%
      compare_value_oht_O2 = previous_value_oht_O2;
      previous_value_oht_O2 = 0;
      Serial.println("compare_value_oht:  " + String(compare_value_oht_O2) + "************************************************");
      if (oht_level_percentage < compare_value_oht_O2) {

        Serial.println("OHT MOTOR 2 NOT WORKING & MOTOR 1 STARTED************************************************");
        controlMotor(4, false);
        delay(500);
        controlMotor(3, true);
        delay(500);
        daily_motor_swap_oht = 0;
        flag_O2 = 0;
      } else {
        flag_O2 = 0;
      }
    }
  } else if (OM2S == 0) {
    flag_O2 = 0;
  }
}

void Send_Data_WIFI(String datasend) {
  delay(writeInterval);
  Serial.println("Sending data to server by WIFI");
  if (WiFi.status() == WL_CONNECTED) {
    WiFiClient client1;
    HTTPClient http;
    http.begin(client1, datasend.c_str());
    //http.begin(Client, datasend);
    int httpResponseCode = http.GET();
    Serial.println(httpResponseCode);
    if (httpResponseCode > 0) {
      String payload = http.getString();
      if ((httpResponseCode == 200) || (httpResponseCode == 202)) {
        Serial.println(PSTR("Data send successfully\n\r"));
      } else {
        Serial.println("Problem in sending Data, Error Code: " + String(httpResponseCode));
        Serial.println("Payload : ");
        Serial.println(payload);
      }
    } else {
      Serial.print("Error code: ");
      Serial.println(httpResponseCode);
      Serial.println(PSTR("Error occurred while sending HTTP POST"));
    }
    datasend = "";
    http.end();
  } else {
    Serial.println("WiFi Disconnected");
    delay(2000);
  }
}

void date_time() {
  HTTPClient http;

  if (http.begin(time_url)) {
    int httpCode = http.GET();

    if (httpCode == HTTP_CODE_OK) {
      String payload = http.getString();

      DynamicJsonDocument jsonDoc(capacity);
      DeserializationError error = deserializeJson(jsonDoc, payload);

      if (error == DeserializationError::Ok) {
        JsonObject jsonObject = jsonDoc.as<JsonObject>();
        TIME = jsonObject["time"];
        C_Time = String(TIME);
        Serial.print("Time: ");
        Serial.println(TIME);

      } else {
        Serial.print("JSON parsing failed: ");
        Serial.println(error.c_str());
      }
    } else {
      Serial.print("HTTP request failed with error code: ");
      Serial.println(httpCode);
    }

    http.end();
  }

  if (http.begin(date_url)) {
    int httpCode = http.GET();

    if (httpCode == HTTP_CODE_OK) {
      String payload = http.getString();

      DynamicJsonDocument jsonDoc(capacity);
      DeserializationError error = deserializeJson(jsonDoc, payload);

      if (error == DeserializationError::Ok) {
        JsonObject jsonObject = jsonDoc.as<JsonObject>();

        DATE = jsonObject["date"];
        C_Date = String(DATE);
        Serial.print("Date: ");
        Serial.println(DATE);

      } else {
        Serial.print("JSON parsing failed: ");
        Serial.println(error.c_str());
      }
    } else {
      Serial.print("HTTP request failed with error code: ");
      Serial.println(httpCode);
    }
    http.end();
  }
}